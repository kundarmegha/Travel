<?php

$username = $_POST['uname'];
$password = $_POST['pasw'];

$row = 1;
global $flag;
$flag == false;
if (($handle = fopen("form-details.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $row++;
        if ($username == $data[5] && $password == $data[6])
        {
        global $flag;
        $flag =true;
        break;
        }
    }
    fclose($handle);
    if ($flag == false)
    {
        echo "login failed";
    }
    else
    {
        echo "login success";
    }
}
?>