<?php
//$servername = "localhost";
//$username = "root";
//$password = "root";
//$dbname = "register";
//
////Create connection
//$conn = new mysqli($servername, $username, $password,$dbname);
//
//if ($conn->connect_error) {
//    die("Connection failed: " . $conn->connect_error);
//}
//else
//    echo "successfully connected <br> ";
//
////function Insertdata($table,$field,$data)
////{
////    $field_values= implode(',',$field);
////    $data_values=implode("','",$data);
////
////    $sql= "INSERT INTO $table (".$field_values.")
////    VALUES ('".$data_values."') ";
////    $result=$conn->query($sql);
////}
////
////$table = "profile";
////$field = array("firstname","lastname");
////$data = array("anush","g");
////$result = Insertdata($table,$field,$data);
////if($result)
////{
////    echo "inserted";
////}
////else
////{
////    echo "not inseterd";
////}
//     $sql = "INSERT INTO profile(firstname,lastname,email)VALUES ('$firstname','$lastname','$email')";
//
//     if (mysqli_query($connection, $sql)) {
//         echo "New record created successfully";
//     } else {
//         echo "Error: " . $sql . "" . mysqli_error($connection);
//     }
//     $connection->close();
//
//
$conn = new mysqli("localhost", "root", "root", "register");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO profile(firstname,lastname,email)VALUES ('$firstname','$lastname','$email')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "" . mysqli_error($conn);
}
$conn->close();
 ?>