<?php

$FullName=$_POST['fullname'];
$FullName= trim($FullName);
$Email=$_POST['email'];
$email = trim($Email);
$Phone=$_POST['phone'];
$Phone = trim($Phone);
$FirstAddress=$_POST['paddress'];
$FirstAddress = trim($FirstAddress);
$birth_date=$_POST["dateofbirth"];
$Gender = $_POST["Gender"];
$Password= $_POST["pasw"];
$ConfirmPassword= $_POST["ConfirmPassword"];
$expert= $_POST["expert"];
$sslc= $_POST["sslc"];
$sslc = trim($sslc);
$pu= $_POST["pu"];
$pu = trim($pu);
$engineering= $_POST["engineering"];
$engineering = trim($engineering);
$file= $_POST["file"];
$country=$_POST["country"];
$state=$_POST["state"];


validate($FullName,"name");
validate($email,"mail");
validate($Password,"password");
validate($ConfirmPassword,"confirm password");
if(!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{12,20}$/', $Password)) {
    echo 'the password does not meet the requirements!<br>';
    exit(1);
}
else {
    $password = password_hash($Password, PASSWORD_DEFAULT);
    if (password_verify($ConfirmPassword, $password)) {
    } else {
        echo 'Invalid password<br>';
        exit(1);
    }
}

function validate($variable,$str)
{
    if (empty($variable)) {
                echo "Enter valid value for $str"."<br />";
                exit(1);
    }
}
$date=date('Y-m-d');
$datetime1 = date_create($date);
$datetime2 = date_create($birth_date);
$interval = date_diff($datetime1, $datetime2);
$age=$interval->format('%y Year %m Month %d Day');


$mailid=strchr($email,"@");
$maildomain=ltrim($mailid,"@");
$lastnametrue=str_word_count($FullName);
if ($lastnametrue==1)
{
    echo "Enter the last name";
    exit(1);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "invalid email";
    exit(1);
}


$avg = ( $sslc + $pu + $engineering ) / 3;
if(($sslc < 60 && $pu < 60 && $engineering<60) && $avg<65)
{
    echo "Marks doesnot satisfy";
    exit(0);
}

if(strlen($Phone) != 10)
{
    echo "Enter the valid mobile number <br>";
    exit(1);
}

if(isset($_POST["submit"])) {
    require_once('database.php');
    $name = explode(" ", "$FullName", 2);
    $firstname = $name[0];
    $lastname = $name[1];


//     $sql = "INSERT INTO profile(firstname,lastname,email,Db)VALUES ('$firstname','$lastname','$email','$birth_date')";
//
//     if (mysqli_query($connection, $sql)) {
//         echo "New record created successfully";
//     } else {
//         echo "Error: " . $sql . "" . mysqli_error($connection);
//     }
//     $connection->close();
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));
    }
    var_dump($image);
}
?>